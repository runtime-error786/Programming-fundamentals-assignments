#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	int arry[100],sum[100]={0}, k;
	int num1=0, num2;
	ifstream myFile;
	ofstream myFile1;
	myFile.open("input.txt");
	myFile1.open("Encrypted.txt");
	myFile>>num2;
	k=num2;
	myFile1<<num2<<" ";
	for(int i=0;i<k;i++)
	{
		myFile>>num2;
		arry[i]=num2;
	}
	for(int i=0;i<k;i++)
	{
		for(int j=0;j<k;j++)
		{
			if(j!=i)
			{
			sum[num1]=sum[num1]+arry[j];      
			}
		}
		num1++;
	}
	for(int i=0;i<k;i++)
	{
		myFile1<<sum[i]<<" ";
		
	}
	myFile.close();
	myFile1.close();
	
	return 0;
}

