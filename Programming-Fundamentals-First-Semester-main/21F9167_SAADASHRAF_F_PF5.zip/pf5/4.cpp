#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	int arry[100],sum=0, decrpt[100]={0},k;
	int num1, num2;
	ifstream myFile;
	ifstream myFile1;
	ofstream myFile2;
	myFile.open("input.txt");
	myFile1.open("Encrypted.txt");
	myFile2.open("decrpycted.txt");
	myFile>>num2;
	myFile1>>num1;
	k=num2;
	for(int i=0;i<k;i++)
	{
		myFile>>num2;
		sum=sum+num2;
	}
	for(int i=0;i<k;i++)
	{
		myFile1>>num1;
		decrpt[i]=sum-num1;
		myFile2<<decrpt[i]<<" ";
		
	}
	myFile.close();
	myFile1.close();
	myFile2.close();
	
	return 0;
}

