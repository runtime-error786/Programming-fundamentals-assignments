#include<iostream>
using namespace std;
int main()
{
	int array[50], array2[50], x, y, num;
	cout << "Enter size of array: ";
	cin >> num;
	for (int i = 0; i < num; i++)
	{
		cin >> array[i];
	}
	for (int i = 0; i < num; i++)
	{
		x = i + 2;
		y = i - 2;
		if (x >= num)
		{
			x = x - num;
		}
		if (y < 0)
		{
			y = num + y;
		}
		array2[i] = array[x] * array[y];
	}
	cout << "The array you entered is: " << endl;
	for (int i = 0; i < num; i++)
	{
		cout << array[i] << " ";
	}
	cout << endl << "the new excecuted array is: " << endl;
	for (int i = 0; i < num; i++)
	{
		cout << array2[i] << " ";
	}
	return 0;
}

