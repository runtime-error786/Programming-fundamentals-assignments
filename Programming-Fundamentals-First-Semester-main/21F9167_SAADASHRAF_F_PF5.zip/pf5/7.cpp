#include <iostream>
using namespace std;
int main()
{
    int array[3][3], rows, cols;
    int Row, Column;
    int j = 0;
    cout << "enter array rows: " << endl;
    cin >> rows;
    cout << "enter array cols: " << endl;
    cin >> cols;
    cout << "input array elements: " << endl;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            cin >> array[i][j];
        }
        cout << endl;
    }
    cout << "Enter row no:";
    cin >> Row;
    cout << "Enter column:";
    cin >> Column;
    int min = array[0][0], max = array[0][0];
    for (int i = 0; i < rows; i++)
    {
        if (i == Row)
        {
            for (int j = 0; j < cols; j++)
            {
                if (max > array[i][j])
                    max = max;
                else
                    max = array[i][j];
            }
        }
    }
    cout << "Maximum  Row:" << max;
    for (int j = 0; j < cols; j++)
    {
        if (j == Column)
        {
            for (int i = 0; i < 3; i++)
            {
                if (min < array[i][j])
                {
                    min = min;
                }
                else
                {
                    min = array[i][j];
                }
            }
        }
    }
    cout << endl << "Minimum Column: " << min;
    return 0;
}
