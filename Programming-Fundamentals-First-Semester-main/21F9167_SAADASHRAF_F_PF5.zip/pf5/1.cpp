#include<iostream>
using namespace std;
int main()
{
	int arr[5], sum[5], c = 0;
	bool flag = 1;
	cout << "Enter values of array : ";
	for (int i = 0; i < 5; i++)
	{
		cin >> arr[i];

	}
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			if (i != j && arr[i] == arr[j])
			{
				c++;
			}
		}
		sum[i] = c;
		c = 0;
	}
	for (int i = 0; i < 5; i++)
	{
		cout << sum[i] << " ";

	}


	return 0;
}

