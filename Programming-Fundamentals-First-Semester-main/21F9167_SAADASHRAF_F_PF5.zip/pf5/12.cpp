#include<iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main()
{
	int arr[20][20],board[5][5];
	srand(time(NULL));
	for(int i=0;i<20;i++)
	{
		for(int j=0;j<20;j++)
		{
			arr[i][j]= rand()%20;
		}
	}
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			board[i][j]=arr[i][j]+0;
			cout<<board[i][j]<<" ";
		}
		cout<<endl;
	}




	
	return 0;
}

