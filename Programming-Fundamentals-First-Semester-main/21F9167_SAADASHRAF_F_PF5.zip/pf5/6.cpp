#include<iostream>
using namespace std;
int main()
{
	int array[10], array2[10], k = 9;
	bool flag = 1;
	cout << "Enter values of array 1: ";
	for (int i = 0; i < 10; i++)
	{
		cin >> array[i];
	}
	cout << endl << "Enter values of array 2: ";
	for (int j = 0; j < 10; j++)
	{
		cin >> array2[j];
	}
	for (int i = 0; i < 10; i++)
	{
		if (array[i] != array2[k])
		{
			flag = 0;
		}
		k--;
	}
	if (flag == 0)
	{
		cout << endl << "1st Arry is not revrese of 2nd Array ";
	}
	else
	{
		cout << endl << "1st Array  is  the reverse of 2nd Array";
	}
	return 0;
}

