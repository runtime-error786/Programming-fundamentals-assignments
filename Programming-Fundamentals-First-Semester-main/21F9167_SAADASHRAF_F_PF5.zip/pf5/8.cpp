#include<iostream>
#include<string>
using namespace std;
int main()
{
	int mat1[100][100], tra[100][100], row, col, sum = 0;
	cout << "Enter no of rows of matrix1: ";
	cin >> row;
	cout << "Enter no of coloumns of matrix1: ";
	cin >> col;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cin >> mat1[i][j];
		}
	}
	for (int i = 0; i < row; ++i)
		for (int j = 0; j < col; ++j) {
			tra[j][i] = mat1[i][j];
		}

	cout << "Original Matrix : " << endl;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << mat1[i][j] << " ";

		}
		cout << endl;

	}
	cout << "TRANSPOSE : " << endl;
	for (int i = 0; i < col; i++)
	{
		for (int j = 0; j < row
			; j++)
		{
			cout << tra[i][j] << " ";

		}
		cout << endl;
	}
	return 0;
}

