#include<iostream>
using namespace std;

int main()
{
	int array[100], size, k, temporary, i;
	cout << "input the size of array: ";
	cin >> size;
	cout << "input the elements  of array: ";
	for (int i = 0; i < size; i++)
	{
		cin >> array[i];
	}
	for (int i = 0; i < size; i++)
	{
		cout << array[i] << " ";
	}
	cout << endl << "Number of shifts: ";
	cin >> k;
	for (int j = 1; j <= k; j++)
	{
		temporary = array[size - 1];
		for (int i = size - 1; i >= 1; i--)
		{
			array[i] = array[i - 1];
		}
		array[i] = temporary;
	}
	cout << endl;
	for (int i = 0; i < size; i++)
	{
		cout << array[i] << " ";
	}
}

