#include<iostream>
#include<fstream>
#include<iomanip>
#include<conio.h>
using namespace std;
int main()
{
	char n, a, b, c;
	int i = 0;
	fstream inf, outf;
	inf.open("New123.txt");
	outf.open("New123.txt");
	cout << "Enter the charachter you want to be replaced : ";
	cin >> a;
	cout << "Enter the charachter you want to replace with : ";
	cin >> b;
	while (!inf.eof())
	{
		inf.get(c);
		if (inf.eof())
		{
			break;
		}
		else if (c == a)
		{
			outf << b;
			i++;
		}
		else
		{
			outf << c;
		}
	}
	outf << endl << "The orignal charachter was " << a;
	outf << endl << "The new charachter is " << b;
	outf << endl << "Charachter was changed " << i << "times.";
	inf.close();
	outf.close();
}