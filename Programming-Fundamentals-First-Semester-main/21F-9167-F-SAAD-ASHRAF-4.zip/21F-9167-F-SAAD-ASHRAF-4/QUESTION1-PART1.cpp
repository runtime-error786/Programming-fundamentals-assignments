#include <iostream>
using namespace std;
int main()
{
    int i, j, rows;
    cout << "Enter Rows:" << endl;
    cin >> rows;
    for (i = rows; i >= 1; i--) {
        for (j = 1; j <= i; j++) {
            cout << ((char)(j + 96));
        }
        cout << endl;
    }
    return 0;
}

