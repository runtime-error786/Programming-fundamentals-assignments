#include <iostream>
#include <iomanip>
#include<fstream>

using namespace std;

int main()
{
    ofstream fout("surveyResults1.txt");
    int choice = 0, CocaCola = 0, Dew = 0, Mirinda = 0, Sprite = 0, total = 0, persons = 0, i = 0, j = 0, k = 0, x = 0;
    cout << "Enter how many person for survey :";
    cin >> persons;
    cout << "Your favorite beverage of the following is?" << endl;
    cout << "1. CocaCola " << endl;
    cout << "2. Dew " << endl;
    cout << "3.  Mirinda " << endl;
    cout << "4. Sprite  " << endl;
    cout << endl;
    cout << " Choose 1, 2, 3, 4 from the above menu or press -1 to exit the program" << endl;

    for (int i = 1; i <= persons; i++) {

        cout << "Input favorite beverage of person # " << i << endl;
        cin >> choice;
        if (choice == -1)
        {

        }


        cout << endl;

        switch (choice)
        {

        case 1:
            CocaCola++;
            break;
        case 2:
            Dew++;
            break;
        case 3:
            Mirinda++;
            break;
        case 4:
            Sprite++;
            break;
        default:
            cout << "Please choose one of the available items on the given menu";

        }

    }

    cout << endl;
    fout << "NO. Of People Participated In Survey: " << persons << endl;
    fout << "CocaCola:" << setw(20) << CocaCola << setw(15);
    while (i < CocaCola) {
        fout << "*";
        i++;
    }
    fout << endl;
    fout << "Dew:" << setw(25) << Dew << setw(15);
    while (j < Dew) {
        fout << "*";
        j++;
    }
    fout << endl;
    fout << "Mirinda:" << setw(21) << Mirinda << setw(15);
    while (k < Mirinda) {
        fout << "*";
        k++;
    }
    fout << endl;
    fout << "Sprite:" << setw(22) << Sprite << setw(15);
    while (x < Sprite) {
        fout << "*";
        x++;
    }

    return 0;
}

