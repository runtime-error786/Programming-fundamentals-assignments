#include<iostream>
using namespace std;
int main() {
	long long a, b, i = 1, c, f = 0, n, e;
	cout << "input the number :";
	cin >> a;
	b = a;
	while (i < a)
	{
		b = b * i;
		i++;
	}
	c = b;
	while (c != 0)
	{
		e = c % 10;
		c = c / 10;
		f = f * 10 + e;
		if (f != 0)
		{
			break;
		}

	}

	cout << "Trangling Zeros Of N:" << a << " " << f << " " << "AsN!(" << b << ")";
	return 0;
}