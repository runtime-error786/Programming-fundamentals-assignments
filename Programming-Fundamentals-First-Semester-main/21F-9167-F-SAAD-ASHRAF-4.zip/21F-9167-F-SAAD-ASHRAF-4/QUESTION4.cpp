#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;
int main()
{
	int a, b = 0, i = 0;
	ifstream f;
	ofstream f1;
	f.open("New.txt");
	f1.open("New1.txt");
	while (!f.eof())
	{
		f >> a;
		while (a != -1)
		{
			b = b + a;
			i++;
			f >> a;
		}
		f1 << static_cast<float>(b) / i << endl;
		i = 0;
		b = 0;
	}
	f.close();
	f1.close();
}